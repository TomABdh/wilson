import location.GHK;
import location.Playground;
import location.Room;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Room ghkRoom=new Room("A","5","0","3");
		GHK ghk=new GHK(ghkRoom);
		
		System.out.println(ghk.active()+" of "+ghk.getClass().getSimpleName());
		
		Playground p1=new Playground();
		
	}

}
