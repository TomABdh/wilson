package mood;

public class Mood {

}
