package location;

abstract public class Building extends Location {
	String name;
	Room room;
}
