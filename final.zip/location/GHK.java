package location;

public class GHK extends Building{
	public GHK(Room room){
		this.room=room;
	}
	public String active(){
		return "study CPS in "+room;
	}
}
