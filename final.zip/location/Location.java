package location;

abstract public class Location {
//	name
	String name=Location.class.getSimpleName();
//	 every location has an build-in event
	abstract public String active();
}
