package location;

public class Room {
	private String section;
	private String floor;
	private String sectondNum;
	private String thirdNum;
	
	public Room(String section,String floor,
			String sectondNum,String thirdNum){
		setSection(section);
		this.floor=floor;
		this.sectondNum=sectondNum;
		this.thirdNum=thirdNum;
	}
	
	String getSection() {
		return section;
	}

	String getFloor() {
		return floor;
	}

	String getSectondNum() {
		return sectondNum;
	}

	String getThirdNum() {
		return thirdNum;
	}
//check if the input valid
	void setSection(String section) {
		if(section.toUpperCase().charAt(0)>65||
				section.toUpperCase().charAt(0)<68) {
			this.section = section;
		}else {
			System.out.println("the section is not exist");
		}
		
	}

	void setFloor(String floor) {
		this.floor = floor;
	}

	void setSectondNum(String sectondNum) {
		this.sectondNum = sectondNum;
	}

	void setThirdNum(String thirdNum) {
		this.thirdNum = thirdNum;
	}

	@Override
	public String toString() {
		return getSection()+getFloor()+ getSectondNum()+ getThirdNum();
	}
	
	
}
