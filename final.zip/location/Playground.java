package location;

public class Playground extends Facilities{
	public String active() {
		return "play football";
	}
}
