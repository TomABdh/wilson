package location;

abstract public class Facilities extends Location{

}
