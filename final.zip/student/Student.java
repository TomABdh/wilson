package student;

public class Student {
	String name;
	String ID;
	CLub club;
	Mood mood;
	Action acion;
}
